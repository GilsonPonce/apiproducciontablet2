<?php

class ControllerRuter{
    public function index(){
        include "ruter/ruters.php";
    }
}